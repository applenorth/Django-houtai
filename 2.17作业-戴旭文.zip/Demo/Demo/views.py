from django.http import HttpResponse
import datetime
from django.shortcuts import render,render_to_response
from Article.models import *
from django.core.paginator import Paginator
# def index(request):
#     s=datetime.datetime.now()
#     return HttpResponse(str(s))
"""
视图：作用
:param request:  形参 包含请求信息的请求对象
:return:    HttpResponse  响应对象
"""
from django.template.loader import get_template
from django.shortcuts import render_to_response
def index(request):
    return render_to_response("index.html")
def base(request):
    return render_to_response("base.html")
def about(request):
    return render_to_response("about.html")
def listpic(request):
    return render_to_response("listpic.html")
# 文章详情
def articleinfo(request,id):
    # 文章的标识，使用id

    article = Article.objects.get(id=id)
    return render_to_response("articleinfo.html",locals())


def newslistpic(request,page):
    # 查询文章
    article=Article.objects.all() #返回的是一个queryset
    pagnitor_obj=Paginator(article,6)
    page_obj=pagnitor_obj.page(page)
    # 通过遍历 pagnitor_obj.page_range->range(1,11)
    # 解决 页码数量太多
    # 获取当前页码，然后生成start和end
    page_num=page_obj.number
    # start
    start=page_num-2
    if start<=2:
        start=1
        end=start+5
    # end
    else:
        end=page_num+3
        if end>=pagnitor_obj.num_pages:
            end=pagnitor_obj.num_pages+1
            start=end-5
    page_range=range(start,end)


    return render_to_response("newslistpic.html",locals())

# 增加多条数据
def add_article(request):
    for i in range(100):
        article=Article()
        article.title="title_%s"%i
        article.content="content_%s"%i
        article.date="2020-02-18"
        article.description="description_%s"%i
        article.author=Author.objects.get(id=1)
        article.save() #在创建关系之前先保存文章数据
    #    多对多关系中的add方法
        article.type.add(Type.objects.get(id=1))
        article.save()



    return HttpResponse("add_article")

# 分页

def fy_test(request,page):
    ## 查询文章的方法
    article = Article.objects.all().order_by("id")
    # print(article)
    ## Paginator(数据集，每页展示的条数)
    paginator_obj = Paginator(article,10)
    print(paginator_obj)
    # print(paginator_obj.count)    ### 数据的总条数
    # print(paginator_obj.num_pages)   ###  总页数
	    # print(paginator_obj.page_range)   ##  range(1, 4)

    page_obj = paginator_obj.page(page)
   # print(page_obj)   #   <Page 1 of 11>
  ## 循环遍历  得到分页之后的数据
    for one in page_obj:
        print(one)
    # print(page_obj.has_next())    ## 是否有下一页  True  False
    # print(page_obj.has_previous())    ## 是否有上一页  True  False
    # print(page_obj.number)    ## 返回当前所在的页码
    # print(page_obj.previous_page_number())   ## 上一页的页码
    # print(page_obj.next_page_number())     ## 下一页的页码
    # print(page_obj.has_other_pages())   ## 是否有其他的页

    return HttpResponse("fy test")
