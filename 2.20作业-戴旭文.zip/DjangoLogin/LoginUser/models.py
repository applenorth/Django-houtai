from django.db import models

# Create your models here.
GENDER_STATUS=(
    (0,"女"),
    (1,"男")

)

class LoginUser(models.Model):
    email=models.EmailField(verbose_name="邮箱")
    password=models.CharField(max_length=32,verbose_name="密码")
    phone_number=models.CharField(max_length=11,verbose_name="手机号",null=True,blank=True)
    age=models.IntegerField(verbose_name="年龄",null=True,blank=True)
    gender=models.IntegerField(choices=GENDER_STATUS,verbose_name="性别",default=1)
    address=models.TextField(verbose_name="地址",null=True,blank=True)

    class Meta:
        db_table="loginuser"