from django.shortcuts import render
from .models import LoginUser
import hashlib
from django.http import HttpResponseRedirect,HttpResponse
# Create your views here.
# 密码加密
def Setpassword(password):
    md5=hashlib.md5()
    md5.update(password.encode())
    result=md5.hexdigest()
    return result


def register(request):
    ##接受参数
    password=request.POST.get("password")
    repassword=request.POST.get("repassword")
    email=request.POST.get("email")
    ##校验数据
    if email and password and password==repassword:
        ##说明有数据
        LoginUser.objects.create(email=email,password=Setpassword(password))
        return HttpResponseRedirect("/login/")

    else:
        ##参数为空
        message="参数为空"

    return render(request,"register.html",locals())

# 登录
def login(request):
    password = request.POST.get("password")
    email = request.POST.get("email")
    if email and password:
        user=LoginUser.objects.filter(email=email,password=Setpassword(password)).first()
        if user:
            #成功登录
            response=HttpResponseRedirect("/")
            response.set_cookie("email", user.email)
            request.session["email"] = user.email

            return response
        else:
            #登录失败
            message="账号密码不正确"
    else:
        message="参数为空"
    return render(request,"login.html")
def index(request):
    return HttpResponse("这是一个首页")

# 登出功能
def logout(request):
    ## 删除cookie 和session
    ## 重定向到登录页
    response = HttpResponseRedirect("/login/")
    response.delete_cookie("username")
    del request.session["username"]

    return response
