from django.apps import AppConfig


class LoginuserConfig(AppConfig):
    name = 'LoginUser'
